package com.pro;
import java.sql.*;
import java.util.*;
//public class ConnectionDao {
//    
//    public static void main(String []args)throws SQLException {
//        try {
//            Class.forName("com.mysql.cj.jdbc.Driver");
//            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
//        Statement stmt = con.createStatement ();
//         ResultSet re=stmt.executeQuery ("insert into student(fName,lName,Rnumber,item) values(?,?,?,?);");
//        
//        }catch (Exception e) {
//            e.getMessage();
//        } 
//    } 
//    }
//  
//package javadatabase;
//import java.sql.*;

public class connectionDao {
   public static void main(String[] args)
   {
       try
       {
           Class.forName("com.mysql.cj.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","");
           Statement stmt= con.createStatement();
           String q="select* from student";
           ResultSet rs=stmt.executeQuery(q);
           while(rs.next())
           {
               String id=rs.getString("id");
               String nm=rs.getString("fName");
               String nm2=rs.getString("lName");
                 int reg=rs.getInt("Rnumber");
               String it=rs.getString("item");
               System.out.print(id+". ");
               System.out.println(nm);

           }
       }
       catch(Exception e)
       {
           e.printStackTrace();
       }
   }
}
